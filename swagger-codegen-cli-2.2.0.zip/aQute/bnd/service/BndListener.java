package aQute.bnd.service;

import java.io.*;

public class BndListener {
    public void changed(File file) {
    }
    
    
}
