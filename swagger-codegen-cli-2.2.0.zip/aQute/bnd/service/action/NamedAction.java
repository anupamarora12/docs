package aQute.bnd.service.action;


public interface NamedAction extends Action {
    String getName();
}
