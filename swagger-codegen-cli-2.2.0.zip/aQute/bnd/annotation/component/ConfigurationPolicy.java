package aQute.bnd.annotation.component;

public enum ConfigurationPolicy {
    optional, require, ignore;
}
