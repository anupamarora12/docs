package aQute.bnd.help;

public interface Warnings {

}
