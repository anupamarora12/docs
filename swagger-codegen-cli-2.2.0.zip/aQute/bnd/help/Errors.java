package aQute.bnd.help;

public interface Errors {

}
