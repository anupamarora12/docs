package aQute.bnd.maven;

public interface BsnToMavenPath {
    String[] getGroupAndArtifact(String bsn);
}
