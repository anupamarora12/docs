package aQute.libg.sed;

public interface Replacer {
    String process(String line);
}
